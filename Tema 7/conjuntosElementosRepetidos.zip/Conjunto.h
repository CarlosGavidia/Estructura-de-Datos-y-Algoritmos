#ifndef _CONJUNTO_H
#define _CONJUNTO_H
#include <iostream>
#include <fstream>

using namespace std;

class EConjuntoLLeno {};

template<class T>
class Conjunto {
  public:
	  Conjunto() {
		  _ocupacion = 0;
	  }
	  bool contiene(const T& elem) const {
		  unsigned int i = 0;
		  while ((i < _ocupacion) && (_elems[i] != elem)) i++;
		  return (i < _ocupacion);
	  }
	  bool contiene(const Conjunto& c) const {
		 unsigned int i = 0;
		 bool puedeContener = true;
		 while ((i < c._ocupacion) && puedeContener) {
			 puedeContener = contiene(c._elems[i++]);
		 }
		 return puedeContener;
	  }
	  Conjunto operator+(const Conjunto& c) const {
		  Conjunto resultado;
		  for (unsigned int i = 0; i < _ocupacion; i++) {
			  resultado.aniade(_elems[i]);
		  }
		  for (unsigned int i = 0; i < c._ocupacion; i++) {
			  resultado.aniade(c._elems[i]);
		  }
		  return resultado;
	  }
	  Conjunto operator-(const Conjunto& c) const {
		  Conjunto resultado;
		  for (unsigned int i = 0; i < _ocupacion; i++) {
			  if (! c.contiene(_elems[i])) resultado.aniade(_elems[i]);
		  }
		  return resultado;
	  }
	  Conjunto operator*(const Conjunto& c) const {
		  Conjunto resultado;
          for (unsigned int i = 0; i < _ocupacion; i++) {
			  if (c.contiene(_elems[i])) resultado.aniade(_elems[i]);
		  }
		  return resultado;
	  }
	  unsigned int cardinalidad() const {
		  unsigned int cardinalidad=0;
		  for (unsigned int i = 0; i < _ocupacion; i++) {
			  bool repetido = false;
			  int j = 0;
			  while ((j < i) && !repetido) {
				  repetido = _elems[i] == _elems[j];
				  j++;
			  }
			  if (!repetido) cardinalidad++;
		  }
		  return cardinalidad;
	  }
	  void aniade(const T& elem) {
		  if (_ocupacion == MAXELEMS) throw EConjuntoLLeno();
		  else _elems[_ocupacion++] = elem;
	  }
	  bool operator==(const Conjunto& c) const {
		  return contiene(c) && c.contiene(*this);
	  }

	  friend ostream& operator<< (ostream& out, const Conjunto<T>& c) {
		  for (unsigned int i = 0; i < c._ocupacion; i++)
			  out << c._elems[i] << " ";
		  return out;
	  }

  private:
	  const static unsigned int MAXELEMS = 100;
	  T _elems[MAXELEMS];
	  unsigned int _ocupacion;
};

#endif