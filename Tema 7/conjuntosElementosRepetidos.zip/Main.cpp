#include "Conjunto.h"
#include <iostream>
#include <string>
#include <sstream>

using namespace std;


void leerC(Conjunto<int>& c) {
	string line;
	getline(cin, line);
	istringstream flujo_linea(line);
	int elem;
	while ((flujo_linea >> elem)) {
		c.aniade(elem);
	}
}
void leer(Conjunto<int>& c) {
	cout << ">";
	c = Conjunto<int>();
	leerC(c);
	cout << c << endl;
}
void contieneElemento(const Conjunto<int>& c) {
	cout << ">";
	string line;
	getline(cin, line);
	istringstream flujo_linea(line);
	int elem;
	flujo_linea >> elem;
	cout << c.contiene(elem) << endl;
}
void contieneConjunto(const Conjunto<int>& c) {
	cout << ">";
	Conjunto<int> cc;
	leerC(cc);
	cout << c.contiene(cc) << endl;
}
void unir(Conjunto<int>& c) {
	cout << ">";
	Conjunto<int> cc;
	leerC(cc);
	c = c+cc;
	cout << c << endl;
}
void interseccion(Conjunto<int>& c) {
	cout << ">";
	Conjunto<int> cc;
	leerC(cc);
	c = c * cc;
	cout << c << endl;
}
void diferencia(Conjunto<int>& c) {
	cout << ">";
	Conjunto<int> cc;
	leerC(cc);
	c = c - cc;
	cout << c << endl;
}
void igualdad(Conjunto<int>& c) {
	cout << ">";
	Conjunto<int> cc;
	leerC(cc);
	cout << (c == cc) << endl;
}
void cardinalidad(const Conjunto<int>& c) {
	cout << c.cardinalidad() << endl;
}


int main() {
	bool fin = false;
	Conjunto<int> c;
	cout << boolalpha;
	while (!fin) {
		cout << "1. Leer" << endl;
		cout << "2. Contiene elemento" << endl;
		cout << "3. Contiene conjunto" << endl;
		cout << "4. Union" << endl;
		cout << "5. Interseccion" << endl;
		cout << "6. Diferencia" << endl;
		cout << "7. Igualdad" << endl;
		cout << "8. Cardinalidad" << endl;
		cout << "9. Salir" << endl;
		string opcion;
		getline(cin,opcion);
		switch (opcion[0]) {
  		  case '1': leer(c); break;
		  case '2': contieneElemento(c); break;
		  case '3': contieneConjunto(c); break;
		  case '4': unir(c); break;
		  case '5': interseccion(c); break;
		  case '6': diferencia(c); break;
		  case '7': igualdad(c); break;
		  case '8': cardinalidad(c); break;
		  case '9': fin = true;
 		}
	}
}