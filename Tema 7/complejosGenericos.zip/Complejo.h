#include <iostream>

using namespace std;

#ifndef _COMPLEJO_H_
#define _COMPLEJO_H

class EDivisionPorCero {};

template<class T>
class Complejo {
public:
	Complejo(T real, T img);
	Complejo operator +(const Complejo& c) const;
	Complejo operator -(const Complejo& c) const;
	Complejo operator *(const Complejo& c) const;
	Complejo operator /(const Complejo& c) const;
	Complejo& operator=(const Complejo& c);
	Complejo& operator+=(const Complejo& c);
	Complejo& operator-=(const Complejo& c);
	Complejo& operator*=(const Complejo& c);
	Complejo& operator/=(const Complejo& c);
	T real();
	T img();
	bool operator==(const Complejo& c);
	friend ostream& operator<<(ostream& out, const Complejo& c) {
		out << c._real << "+" << c._img << "i";
		return out;
	}
private:
	T _real;
	T _img;
};

template <class T>
Complejo<T>::Complejo(T real, T img) {
	_real = real;
	_img = img;
}

template <class T>
Complejo<T> Complejo<T>::operator +(const Complejo& c) const {
	return Complejo(_real + c._real, _img + c._img);
}

template <class T>
Complejo<T> Complejo<T>::operator -(const Complejo& c) const {
	return Complejo(_real - c._real, _img - c._img);
}

template <class T>
Complejo<T> Complejo<T>::operator *(const Complejo& c) const {
	return Complejo(_real*c._real - _img*c._img, _real*c._img + _img*c._real);
}

template <class T>
Complejo<T> Complejo<T>::operator /(const Complejo& c) const {
	if ((c._real == 0) && (c._img == 0)) throw EDivisionPorCero();
	else {
		T factor_escala = c._real*c._real + c._img*c._img;
		return Complejo((_real*c._real + _img*c._img) / factor_escala,
			(_img*c._real - _real*c._img) / factor_escala);
	}
}

template <class T>
Complejo<T>& Complejo<T>::operator= (const Complejo& c) {
	_real = c._real;
	_img = c._img;
	return *this;
}

template <class T>
Complejo<T>& Complejo<T>::operator +=(const Complejo& c) {
	Complejo suma = *this + c;
	_real = suma._real;
	_img = suma._img;
	return *this;
}

template <class T>
Complejo<T>& Complejo<T>::operator -=(const Complejo& c) {
	Complejo resta = *this - c;
	_real = resta._real;
	_img = resta._img;
	return *this;
}

template <class T>
Complejo<T>& Complejo<T>::operator *=(const Complejo& c) {
	Complejo producto = *this * c;
	_real = producto._real;
	_img = producto._img;
	return *this;
}

template <class T>
Complejo<T>& Complejo<T>::operator /=(const Complejo& c) {
	Complejo division = *this / c;
	_real = division._real;
	_img = division._img;
	return *this;
}

template <class T>
T Complejo<T>::real() { return _real; }

template <class T>
T Complejo<T>::img() { return _img; }

template <class T>
bool Complejo<T>::operator==(const Complejo& c) {
	return (_real == c._real) && (_img == c._img);
}

#endif

