#include "Punto.h"

Punto::Punto() {}

Punto::Punto(float x, float y) {
	_coordenadas = Par<float, float>(x, y);
}


float Punto::coordenadaX() const {
	return _coordenadas.elem1();
}

float Punto::coordenadaY() const {
	return _coordenadas.elem2();
}

bool Punto::operator==(const Punto&p) const {
	return (_coordenadas.elem1() == p._coordenadas.elem1())
		&&
		(_coordenadas.elem2() == p._coordenadas.elem2());
}

