#ifndef _PAR_H
#define _PAR_H

template<class T1, class T2>
class Par {
  public:
	Par();
	Par(const T1& elm1, const T2& elm2);
	T1 elem1() const;
	T2 elem2() const;
	bool operator==(const Par& p);

private:
	  T1 _1;
	  T2 _2;
};

template<class T1, class T2>
Par<T1, T2>::Par() {}

template<class T1, class T2>
Par<T1, T2>::Par(const T1& elem1, const T2& elem2) {
	_1 = elem1;
	_2 = elem2;
}

template<class T1, class T2>
T1 Par<T1, T2>::elem1() const {
	return _1;
}

template<class T1, class T2>
T2 Par<T1, T2>::elem2() const {
	return _2;
}

template<class T1, class T2>
bool Par<T1, T2>::operator==(const Par& p) {
	return (_1 == p._1) && (_2 == p._2);
}

#endif